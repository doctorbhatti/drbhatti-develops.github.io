<?php 
		$sq_base_url='/';
		$sq_hostname='localhost';
		$sq_dbname='damptor';
		$sq_dbusername='root';
		$sq_dbpassword='';
		?>