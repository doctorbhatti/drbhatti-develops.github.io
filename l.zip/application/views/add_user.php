
<html lang="en">
  <head>
  <title> Add Account Type</title>
 <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">


  
  <!-- Custom fonts for this template-->
  <link href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
 <!-- custom css -->
	<link href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/css/style.css?q=1601824049" rel="stylesheet">
	
	<!-- Custom styles for this template-->
  <link href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/css/sb-admin-2.min.css" rel="stylesheet">

	
	
  <style>
  html,body,h1,h2,h3,h4,p,div,span,ul,li,a{
    direction: ltr;
}
.btn-default{
	
	border:1px solid #c8c4c4;
	
}
form{
	width: 100%;
}

.sidebar {
    width: 16rem!important;
}
@media only screen and (max-width: 900px) {

.sidebar{
display:none;
}
.sidebar .sidebar-brand .sidebar-brand-text {
display:block;
}
}
  </style>	
	<script src="https://savsoftquiz.com/savsoftquiz_v5_enterprise/vendor/jquery/jquery.min.js"></script>
  <script src="https://savsoftquiz.com/savsoftquiz_v5_enterprise/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="https://savsoftquiz.com/savsoftquiz_v5_enterprise/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="https://savsoftquiz.com/savsoftquiz_v5_enterprise/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="https://savsoftquiz.com/savsoftquiz_v5_enterprise/vendor/chart.js/Chart.min.js"></script>

   
	
	<script>
	
	var base_url="https://savsoftquiz.com/savsoftquiz_v5_enterprise/";

	</script>
	
	 
		<!-- custom javascript -->
	  	<script src="https://savsoftquiz.com/savsoftquiz_v5_enterprise/js/basic.js?q=1601824049"></script>
		
	<!-- firebase messaging menifest.json -->
	 <link rel="manifest" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/js/manifest.json">
	 
	 
	 <script>

$(document).ready(function(){
  $("#sidebarToggleTop").click(function(){
    $("ul").toggle();
  });
});
</script> 	 




 </head>
  
  
  
  
  
  
<body id="page-top">



	  <!-- Page Wrapper -->
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="https://savsoftquiz.com">
         
        <div class="sidebar-brand-text mx-3">Savsoft Quiz <sup>5.5</sup> </div>
		
		
      </a>
<center><span style="color:#ffffff;"> </span></center>
      <!-- Divider -->
      <hr class="sidebar-divider my-0">
      			
      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading  
      <div class="sidebar-heading">
        Interface
      </div>
-->


 	      <!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
      <i class="fas fa-fw fa-users"></i>
       <span>Users</span>
    </a>
		
<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
<div class="bg-white py-2 collapse-inner rounded">
<a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/user/new_user">Add new</a> 
<a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/user">Users List</a> 
          
<a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/appointment/myappointment/">My Appointment</a>   
      
</div>
</div>
</li>
				
	  
	  
	  
	  
 <!-- Nav Item -  Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-university"></i>
          <span>Question Bank</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
 
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/qbank/pre_new_question">Add new</a>
 
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/qbank">Question List</a>
          </div>
        </div>
</li>






 
 
      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseQuiz" aria-expanded="true" aria-controls="collapseQuiz">
          <i class="fas fa-fw fa-chalkboard-teacher"></i>
          <span>Quiz </span>
        </a>
        <div id="collapseQuiz" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
             
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/quiz/add_new">Add new</a>
		  
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/quiz">Quiz List</a>
             
          </div>
        </div>
      </li>
 
     <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseResult" aria-expanded="true" aria-controls="collapseResult">
          <i class="fas fa-fw fa-folder"></i>
          <span>Result</a></span>
        </a>
        <div id="collapseResult" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
 
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/result">Result List</a>
 
          </div>
        </div>
      </li>

 
     <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseStudy" aria-expanded="true" aria-controls="collapseStudy">
          <i class="fas fa-fw fa-book"></i>
          <span>Study Material</span>
        </a>
        <div id="collapseStudy" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
          
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/study_material">Study Material</a>  
          </div>
        </div>
      </li>

 
     <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSetting" aria-expanded="true" aria-controls="collapseSetting">
          <i class="fas fa-fw fa-cog"></i>
          <span>Setting</span>
        </a>
        <div id="collapseSetting" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
          
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/setting">Setting</a>
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/notification">Notification</a>
            <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/user/group_list">User Group</a> 
           <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/qbank/category_list">Category List</a> 
           <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/qbank/level_list">Level List</a> 
           <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/advertisment">Advertisment</a> 
           <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/account">Account Type</a></a> 
           <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/user/custom_fields">Custom registration fields</a>  
           <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/payment_gateway">Payment History</a> 
          </div>
        </div>
      </li>

 


     <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSupport" aria-expanded="true" aria-controls="collapseStudy">
          <i class="fas fa-fw fa-question-circle"></i>
          <span>Support</span>
        </a>
        <div id="collapseSupport" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
          
          <a class="collapse-item" href="https://savsoftquiz.com/support.php">Support</a>
          </div>
        </div>
      </li>
	  
	  
	 

  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLanding" aria-expanded="true" aria-controls="collapseStudy">
          <i class="fas fa-fw fa-puzzle-piece"></i>
          <span>Landing Page <sub >New</sub></span>
        </a>
        <div id="collapseLanding" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
          
          <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/cms_admin/menu_list">Menu</a>
           
          <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/cms_admin/page_list">Pages/Post</a>
          <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/cms_admin/slider">Slider</a>
           <a class="collapse-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/cms_admin/design">Design</a>
         </div>
        </div>
      </li>


     </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

      
	  	
	  
	              <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <!-- Counter - Alerts -->
                <span class="badge badge-danger badge-counter">3</span>
              </a>
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                 Notification
                </h6>
				                <a class="dropdown-item d-flex align-items-center" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/notification">
                  
                  <div>
                    <div class="small text-gray-500">2019-03-18 01:20:37</div>
                    <span class="font-weight-bold">Developer </span>
                  </div>
                </a>
					 
					                <a class="dropdown-item d-flex align-items-center" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/notification">
                  
                  <div>
                    <div class="small text-gray-500">2019-03-18 07:41:51</div>
                    <span class="font-weight-bold">Developer </span>
                  </div>
                </a>
					 
					                <a class="dropdown-item d-flex align-items-center" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/notification">
                  
                  <div>
                    <div class="small text-gray-500">2020-09-28 08:05:09</div>
                    <span class="font-weight-bold">hi </span>
                  </div>
                </a>
					 
					             
              </div>
            </li>
			
			
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
               <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <span class="mr-2 d-none d-lg-inline text-gray-600 small" style="display:block !important;">
				
				
				Admin Admin </span>
               <!-- <img class="img-profile rounded-circle" src=""> -->
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
			  

			  
			  
			  
                <a class="dropdown-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/user/edit_user/1">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  My Account                </a>
				
				  


                   <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/user/logout"  >
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

		
	 <!-- Begin Page Content -->
        <div class="container-fluid">

 	<center></center>
	
		
	
 	

	
		
		 
		
  
   
 
 <style>
@media screen and (max-width:992px) {
	.container, .container-fluid{
	  padding-left: 0.3rem;
	  padding-right: 0.3rem;	 
	 }
	 .card-body{
	   padding: 0rem;
	 }
}

 </style>

<div class="container">

   
 <h3> Add Account Type</h3>
   
 

  <div class="row">
     <form method="post" action="https://savsoftquiz.com/savsoftquiz_v5_enterprise/index.php/account/insert_account">
	
<div class="col-md-8">
<br> 
 <div class="login-panel panel panel-default">
		<div class="panel-body"> 
	
	
	
				
		
		
							 

			
			 
			
			
			 
			
			
<div class="form-group">
<label>Name</label>
<input type="text" name="name" class="form-control" >
</div>
			<div class="form-group">
			<label>Users</label><br>
				 
			 <label class="checkbox-inline">
      <input type="checkbox" value="Add" name="users[]">Add
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="Edit" name="users[]">Edit
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="view" name="users[]">view
      
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List" name="users[]">List 
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List_all" name="users[]">List All
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="My_account" name="users[]">My Account
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="Remove" name="users[]">Remove
    </label>
    
    </div>
	
	
	
	
	   <div class="form-group">
			<label>Quiz</label><br>
			<label class="checkbox-inline">
      <input type="checkbox" value="Attempt" name="quiz[]"   >Attempt
    </label>	 
			 <label class="checkbox-inline">
      <input type="checkbox" value="Add" name="quiz[]"   >Add
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="Edit" name="quiz[]"   >Edit
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="View" name="quiz[]"   >view
      
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List" name="quiz[]"   >List 
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List_all" name="quiz[]"   >List All
    </label>
    
    <label class="checkbox-inline">
      <input type="checkbox" value="Remove" name="quiz[]"   >Remove
    </label>
    
    </div>
	
	
	
 
    <div class="form-group">
     <label>Result</label><br>
			
		
    <label class="checkbox-inline">
      <input type="checkbox" value="View" name="result[]">view
      
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List" name="result[]">List 
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List_all" name="result[]">List All
    </label>
   
    <label class="checkbox-inline">
      <input type="checkbox" value="Remove" name="result[]">Remove
    </label>
    
    </div>
    <div class="form-group">
        <label>Questions</label><br>
			
      <label class="checkbox-inline">
      <input type="checkbox" value="Add" name="questions[]">Add
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="View" name="questions[]">view
      
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="list" name="questions[]">List 
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List_all" name="questions[]">List All
    </label>
    
    <label class="checkbox-inline">
      <input type="checkbox" value="Remove" name="questions[]">Remove
    </label>
    
    </div>
	
	
	
	
    
      <div class="form-group">
			<label>Study Material</label><br>
			 
			 <label class="checkbox-inline">
      <input type="checkbox" value="Add" name="study_material[]"   >Add
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="Edit" name="study_material[]"   >Edit
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="View" name="study_material[]"   >view
      
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List" name="study_material[]"   >List 
    </label>
    <label class="checkbox-inline">
      <input type="checkbox" value="List_all" name="study_material[]"   >List All
    </label>
    
    <label class="checkbox-inline">
      <input type="checkbox" value="Remove" name="study_material[]"   >Remove
    </label>
    
    </div>
   
   
   
   
     <div class="form-group">
        <label>Setting/Payments</label><br>
        <label class="checkbox-inline">
      <input type="checkbox" value="All" name="setting">All
        </div>
	<button class="btn btn-info" type="submit">Submit</button>
 
		</div>
</div>
 
 
 
 
</div>
      </form>
</div>

 



</div>
<script type="text/javascript"
     src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML">
  </script>
    
  </div>
  
  
<center>	</center>


	 
<div class="container" style="text-align:right;">
Powered by <a href="https://www.techkshetrainfo.com/" target="_blank">TechKshetra Info Solutions</a>
</div>
</div>	   
		

	<script type="text/javascript" src="https://savsoftquiz.com/savsoftquiz_v5_enterprise/editor/tinymce.min.js"></script>
	 
 
	<script type="text/javascript">
  tinymce.init({
  selector: 'textarea',
  images_dataimg_filter: function(img) {
    return img.hasAttribute('internal-blob');
  },
  height: 100,
  theme: 'modern',
  plugins: [
    'advlist autolink lists link image jbimages eqneditor tiny_mce_wiris  charmap print preview hr anchor pagebreak',
    'searchreplace wordcount visualblocks visualchars code fullscreen',
    'insertdatetime media nonbreaking save table contextmenu directionality',
    'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
  ],
  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image |  jbimages | eqneditor  | tiny_mce_wiris_formulaEditor | tiny_mce_wiris_formulaEditorChemistry | tiny_mce_wiris_CAS ',
  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample help',
  image_advtab: true,
  templates: [
    { title: 'Test template 1', content: 'Test 1' },
    { title: 'Test template 2', content: 'Test 2' }
  ],
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    '//www.tinymce.com/css/codepen.min.css'
  ]
 });
 
 </script>

 
 

	
	





 

<div id="messages"></div>

 



<!-- duplicate question check -->
<div id="duplicate_question" style="display:none;position:fixed;z-index:1000;width:100%;bottom:0px;height:220px;overflow-y:auto;background:#212121;color:#ffffff;padding:8px;">

<a href="javascript:canceldupli();" style="float:right;"><i class="fa fa-times"></i></a>
<div id="duplicate_question2">

</div>
</div>
<script>
var showdupli=1;
function canceldupli(){
$('#duplicate_question').css('display','none');	
showdupli=0;
}
		
function myCustomOnChangeHandler(inst) {
         
      tinyMCE.triggerSave();
       var question=$('#question').val();
if(question != '' && showdupli == 1){
$('#duplicate_question').css('display','block');

	var formData = {question:question};
	$.ajax({
		 type: "POST",
		 data : formData,
		url: base_url + "index.php/duplicate_question/index",
		success: function(data){
		 
		if(data.trim() != ''){
	 	$('#duplicate_question2').html(data);
	 	}else{
	 	 
	 	$('#duplicate_question').css('display','none');
	 	}
			},
		error: function(xhr,status,strErr){
			//alert(status);
			}	
		});
		}else{
$('#duplicate_question').css('display','none');		
		}
}

 		
</script>
<!-- dupllicate question check ends -->
  <div style="background:#fcf171;color:#212121;padding:5px;"><center>Some functions like file upload, delete rows are disabled in demo due to security reason. Demo data reset every 30 mins. </center></div>


<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-46712501-1', 'savsoftquiz.com');
  ga('send', 'pageview');

</script> 
 
 </body>
</html>
 <script>
$(function(){
    $("input[type='text']").on("keydown", function(e){
        if (e.shiftKey && (e.which == 188 || e.which == 190)) {
        alert("Html tag not allow in Demo");
            e.preventDefault();
        }
    });
});

$(function(){
    $("textarea").on("keydown", function(e){
        if (e.shiftKey && (e.which == 188 || e.which == 190)) {
        alert("Html tag not allow in Demo");
            e.preventDefault();
        }
    });
});


</script>
<script type="text/javascript">
$(document).ready(function () {
    //Disable cut copy paste
    $('body').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
   
    //Disable mouse right click
    $("body").on("contextmenu",function(e){
        return false;
    });
});
</script>
