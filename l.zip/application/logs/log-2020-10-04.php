<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-04 00:10:05 --> Severity: Warning --> mysqli::__construct(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\application\config\config.php 515
ERROR - 2020-10-04 00:11:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 00:11:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 00:11:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 00:16:18 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 155
ERROR - 2020-10-04 00:16:48 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 193
ERROR - 2020-10-04 00:18:46 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 193
ERROR - 2020-10-04 00:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 00:20:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\system\libraries\Email.php 1896
ERROR - 2020-10-04 00:20:28 --> Could not find the language line "hello"
ERROR - 2020-10-04 00:20:28 --> Could not find the language line "user_id"
ERROR - 2020-10-04 00:20:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 00:20:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `savsoft_result`.`uid`' at line 5 - Invalid query: SELECT `savsoft_result`.`uid`
FROM `savsoft_result`
WHERE `savsoft_result`.`quid` IS NULL
AND `savsoft_result`.`uid` IS NOT NULL
AND `savsoft_result`.`score_obtained` < `IS` `NULL`
GROUP BY `savsoft_result`.`uid`
ERROR - 2020-10-04 00:20:31 --> Severity: error --> Exception: Call to a member function num_rows() on boolean C:\xampp\htdocs\application\models\Result_model.php 161
ERROR - 2020-10-04 00:20:42 --> Severity: error --> Exception: No block-level parent found.  Not good. C:\xampp\htdocs\application\libraries\dompdf\include\inline_positioner.cls.php 37
ERROR - 2020-10-04 00:20:52 --> Could not find the language line "hello"
ERROR - 2020-10-04 00:20:52 --> Could not find the language line "user_id"
ERROR - 2020-10-04 00:20:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 00:20:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
GROUP BY `savsoft_result`.`uid`' at line 5 - Invalid query: SELECT `savsoft_result`.`uid`
FROM `savsoft_result`
WHERE `savsoft_result`.`quid` IS NULL
AND `savsoft_result`.`uid` IS NOT NULL
AND `savsoft_result`.`score_obtained` < `IS` `NULL`
GROUP BY `savsoft_result`.`uid`
ERROR - 2020-10-04 00:20:56 --> Severity: error --> Exception: Call to a member function num_rows() on boolean C:\xampp\htdocs\application\models\Result_model.php 161
ERROR - 2020-10-04 00:28:00 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:28:02 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:28:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 00:28:11 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:28:15 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:31:50 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 193
ERROR - 2020-10-04 00:31:50 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:31:54 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:31:55 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:31:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 00:32:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\system\libraries\Email.php 1896
ERROR - 2020-10-04 00:32:27 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 00:32:27 --> Could not find the language line "hello"
ERROR - 2020-10-04 00:32:27 --> Could not find the language line "user_id"
ERROR - 2020-10-04 00:32:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 00:32:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') order by FIELD(savsoft_options.qid,)' at line 1 - Invalid query: select * from savsoft_options where qid in () order by FIELD(savsoft_options.qid,)
ERROR - 2020-10-04 00:32:27 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\application\models\Quiz_model.php 316
ERROR - 2020-10-04 00:32:31 --> Severity: error --> Exception: No block-level parent found.  Not good. C:\xampp\htdocs\application\libraries\dompdf\include\inline_positioner.cls.php 37
ERROR - 2020-10-04 00:32:43 --> Severity: error --> Exception: No block-level parent found.  Not good. C:\xampp\htdocs\application\libraries\dompdf\include\inline_positioner.cls.php 37
ERROR - 2020-10-04 01:09:09 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 01:09:09 --> Could not find the language line "hello"
ERROR - 2020-10-04 01:09:09 --> Could not find the language line "user_id"
ERROR - 2020-10-04 01:09:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 01:09:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') order by FIELD(savsoft_options.qid,)' at line 1 - Invalid query: select * from savsoft_options where qid in () order by FIELD(savsoft_options.qid,)
ERROR - 2020-10-04 01:09:09 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\application\models\Quiz_model.php 316
ERROR - 2020-10-04 01:09:15 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 01:09:15 --> Could not find the language line "hello"
ERROR - 2020-10-04 01:09:15 --> Could not find the language line "user_id"
ERROR - 2020-10-04 01:09:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 01:09:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') order by FIELD(savsoft_options.qid,)' at line 1 - Invalid query: select * from savsoft_options where qid in () order by FIELD(savsoft_options.qid,)
ERROR - 2020-10-04 01:09:15 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\application\models\Quiz_model.php 316
ERROR - 2020-10-04 01:09:16 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 01:10:36 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 01:10:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 01:10:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 01:10:47 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 10:42:31 --> Could not find the language line "quizify"
ERROR - 2020-10-04 10:44:45 --> Could not find the language line "quizify"
ERROR - 2020-10-04 10:45:01 --> Could not find the language line "advertisment"
ERROR - 2020-10-04 10:45:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 10:45:01 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 10:47:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 492
ERROR - 2020-10-04 10:47:29 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 492
ERROR - 2020-10-04 10:47:30 --> Could not find the language line "quizify"
ERROR - 2020-10-04 10:47:40 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 492
ERROR - 2020-10-04 10:48:03 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 494
ERROR - 2020-10-04 10:48:04 --> Could not find the language line "quizify"
ERROR - 2020-10-04 10:48:09 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 494
ERROR - 2020-10-04 10:48:43 --> Could not find the language line "quizify"
ERROR - 2020-10-04 10:48:54 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 492
ERROR - 2020-10-04 10:49:18 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 492
ERROR - 2020-10-04 10:49:28 --> Could not find the language line "quizify"
ERROR - 2020-10-04 10:49:34 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\application\views\header.php 492
ERROR - 2020-10-04 10:50:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 10:50:29 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 10:51:53 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 155
ERROR - 2020-10-04 10:52:19 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 193
ERROR - 2020-10-04 10:53:05 --> Could not find the language line "quizify"
ERROR - 2020-10-04 10:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\User_model.php 421
ERROR - 2020-10-04 10:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 10:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 10:56:03 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\system\libraries\Email.php 1896
ERROR - 2020-10-04 10:56:03 --> Could not find the language line "hello"
ERROR - 2020-10-04 10:56:03 --> Could not find the language line "user_id"
ERROR - 2020-10-04 10:56:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 10:56:12 --> Severity: error --> Exception: No block-level parent found.  Not good. C:\xampp\htdocs\application\libraries\dompdf\include\inline_positioner.cls.php 37
ERROR - 2020-10-04 10:56:25 --> Could not find the language line "hello"
ERROR - 2020-10-04 10:56:25 --> Could not find the language line "user_id"
ERROR - 2020-10-04 10:56:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 10:57:09 --> Could not find the language line "appointment_timing"
ERROR - 2020-10-04 10:58:41 --> Could not find the language line "hello"
ERROR - 2020-10-04 10:58:41 --> Could not find the language line "user_id"
ERROR - 2020-10-04 10:58:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 356
ERROR - 2020-10-04 10:58:43 --> Severity: error --> Exception: No block-level parent found.  Not good. C:\xampp\htdocs\application\libraries\dompdf\include\inline_positioner.cls.php 37
ERROR - 2020-10-04 11:01:49 --> Severity: error --> Exception: No block-level parent found.  Not good. C:\xampp\htdocs\application\libraries\dompdf\include\inline_positioner.cls.php 37
ERROR - 2020-10-04 11:03:06 --> Could not find the language line "hello"
ERROR - 2020-10-04 11:03:06 --> Could not find the language line "user_id"
ERROR - 2020-10-04 11:03:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 354
ERROR - 2020-10-04 11:04:00 --> Could not find the language line "hello"
ERROR - 2020-10-04 11:04:00 --> Could not find the language line "user_id"
ERROR - 2020-10-04 11:04:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 354
ERROR - 2020-10-04 11:04:12 --> Could not find the language line "hello"
ERROR - 2020-10-04 11:04:12 --> Could not find the language line "user_id"
ERROR - 2020-10-04 11:04:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 354
ERROR - 2020-10-04 11:06:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:06:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:08:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:08:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:08:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\profile.php 110
ERROR - 2020-10-04 11:08:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\profile.php 199
ERROR - 2020-10-04 11:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\profile.php 110
ERROR - 2020-10-04 11:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\profile.php 199
ERROR - 2020-10-04 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:09:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:09:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:09:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:09:47 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:13:16 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:19:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:19:38 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:19:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:19:51 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:21:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:21:21 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 236
ERROR - 2020-10-04 11:23:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:23:31 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:24:11 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:24:46 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:25:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:25:29 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 155
ERROR - 2020-10-04 11:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:25:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:26:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:26:08 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:26:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:26:40 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:27:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:27:44 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:27:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:27:48 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:28:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:28:46 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:31:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:31:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:31:44 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:32:19 --> Severity: Warning --> Division by zero C:\xampp\htdocs\application\views\dashboard.php 237
ERROR - 2020-10-04 11:33:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:33:28 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 155
ERROR - 2020-10-04 11:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:35:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:35:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:38:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:39:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:39:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:40:00 --> Could not find the language line "hello"
ERROR - 2020-10-04 11:40:00 --> Could not find the language line "user_id"
ERROR - 2020-10-04 11:40:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 354
ERROR - 2020-10-04 11:40:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 174
ERROR - 2020-10-04 11:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 183
ERROR - 2020-10-04 11:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 11:40:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 229
ERROR - 2020-10-04 11:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 253
ERROR - 2020-10-04 12:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\User_model.php 421
ERROR - 2020-10-04 14:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 14:32:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 14:37:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 14:37:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\system\libraries\Email.php 1902
ERROR - 2020-10-04 14:37:29 --> Could not find the language line "hello"
ERROR - 2020-10-04 14:37:29 --> Could not find the language line "user_id"
ERROR - 2020-10-04 14:37:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 354
ERROR - 2020-10-04 15:49:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 15:50:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') ORDER BY FIELD(qid,)' at line 1 - Invalid query: select * from savsoft_qbank join savsoft_category on savsoft_category.cid=savsoft_qbank.cid where qid in () ORDER BY FIELD(qid,)  
ERROR - 2020-10-04 15:50:06 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\application\models\Quiz_model.php 511
ERROR - 2020-10-04 15:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 15:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:04:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:18:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:18:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:32:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:38:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 16:51:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 17:57:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 20:35:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 20:44:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 20:46:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 20:57:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:06:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 174
ERROR - 2020-10-04 21:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 183
ERROR - 2020-10-04 21:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:06:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 229
ERROR - 2020-10-04 21:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 253
ERROR - 2020-10-04 21:09:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 174
ERROR - 2020-10-04 21:09:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 183
ERROR - 2020-10-04 21:09:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:09:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 229
ERROR - 2020-10-04 21:09:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 253
ERROR - 2020-10-04 21:09:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 174
ERROR - 2020-10-04 21:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 183
ERROR - 2020-10-04 21:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:09:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 229
ERROR - 2020-10-04 21:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 253
ERROR - 2020-10-04 21:09:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 174
ERROR - 2020-10-04 21:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 183
ERROR - 2020-10-04 21:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:09:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\dashboard.php 229
ERROR - 2020-10-04 21:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 253
ERROR - 2020-10-04 21:12:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 21:12:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 21:12:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 21:14:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 21:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\models\Quiz_model.php 878
ERROR - 2020-10-04 21:16:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\system\libraries\Email.php 1902
ERROR - 2020-10-04 21:16:30 --> Could not find the language line "hello"
ERROR - 2020-10-04 21:16:30 --> Could not find the language line "user_id"
ERROR - 2020-10-04 21:16:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 354
ERROR - 2020-10-04 21:16:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:17:11 --> Could not find the language line "hello"
ERROR - 2020-10-04 21:17:11 --> Could not find the language line "user_id"
ERROR - 2020-10-04 21:17:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\application\views\view_result.php 354
ERROR - 2020-10-04 21:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:22:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:22:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:24:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:25:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:26:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:29:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:37:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 21:40:13 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 155
ERROR - 2020-10-04 21:44:52 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\models\Quiz_model.php 155
ERROR - 2020-10-04 21:50:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 22:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 22:04:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 22:05:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 22:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
ERROR - 2020-10-04 22:37:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\application\views\dashboard.php 211
